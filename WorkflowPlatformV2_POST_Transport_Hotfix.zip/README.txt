WorkflowPlatform V2 — targeted POST transport compatibility patch
Baseline: OperationTester_AuthDiagnostics.cs (902 lines), applied to Clean UI Response Hotfix + Corporate API POST Hotfix.

Replace Services/OperationTester.cs only. Do not replace IntegrationEndpoints.cs or reset the database.
This patch does not claim that an upstream 401 is fixed: the corporate endpoint is unavailable here.

Find the exact operation ID, BaseUrl and UrlPath using a read-only query:
SELECT o.OperationId,o.Name,s.BaseUrl,o.UrlPath,o.HttpMethod
FROM integration.Operations o JOIN integration.DataSources s ON s.DataSourceId=o.DataSourceId
WHERE o.HttpMethod='POST';

Merge the following keys into your existing Integration configuration. Example only; replace ID, URL and path with exact saved values. Preserve proxy, host approval, POST intake approval and secret settings.
"EnableAuthDiagnostics": true,
"PostTransportProfiles": [
  {
    "OperationId": 1,
    "BaseUrl": "https://api.example.com",
    "UrlPath": "/api/customer/details",
    "OmitJsonCharset": true
  }
]
OmitJsonCharset=true is only appropriate if the successful Postman request uses application/json without a charset. Set false or remove profile otherwise.
Optional PreferredAddress: set to one exact IT-approved working IP observed in the DNS and diagnostic output. The address must be among the current vetted DNS answers; otherwise execution is rejected. Do not use it for CorporateGateway mode. No automatic fallback or POST replay is introduced. The original TLS hostname stays intact.

Without a profile, request behavior is unchanged; 401 diagnostic logging is emitted at Warning level. With diagnostics enabled, successful requests are logged as well. Compare the operation ID, pinned address, HTTP version, content type and body byte count. No token, query string, or payload is logged. Internal IPs should remain in restricted internal logs.

Rebuild and restart using dotnet build / dotnet run (or your normal deployment). Test with approved read-only or sandbox POST requests and synthetic data. Do not repeat financial write requests. Compare 200 and 401 entries. If both occur with identical transport settings, ask the external API/gateway team to trace the corresponding requests; a single IP can represent multiple upstream servers. Check Postman's effective headers and JSON body locally. Do not send credentials/customer data to chat.

Validation: 222/222 existing Node regression tests passed on assembled baseline. Four backend Python static checks passed (82 procedures, 46 mutation routes, 26 C# files). Additional targeted source checks passed. .NET SDK and corporate API unavailable; compilation and live tests NOT performed. No UI, SQL, GET transport, role or mapping changes. No automatic POST retry, TLS bypass or external authentication bypass.
